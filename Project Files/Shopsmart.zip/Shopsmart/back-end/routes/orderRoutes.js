const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const User = require('../models/User');
const nodemailer = require('nodemailer');

// ✅ Email sending function using environment variables
const sendOrderConfirmationEmail = async (to, orderDetails) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER, // Your Gmail (from .env)
      pass: process.env.EMAIL_PASS  // Gmail App Password
    }
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject: 'Order Confirmation - ShopSmart',
    html: `<h3>Thank you for your order!</h3>
           <p>Total: ₹${orderDetails.total}</p>
           <p>We’ll deliver your items soon. 🛒</p>`
  };

  return transporter.sendMail(mailOptions);
};

// ✅ Place an order and send confirmation email
router.post('/orders', async (req, res) => {
  try {
    const { items, totalPrice, userId } = req.body;

    if (!userId) {
      return res.status(400).json({ message: 'Missing userId' });
    }

    // Save order
    const order = new Order({ user: userId, items, totalPrice });
    await order.save();

    // Get user email
    const user = await User.findById(userId);
    if (user && user.email) {
      console.log("📧 Sending email to:", user.email);

      try {
        await sendOrderConfirmationEmail(user.email, {
          total: totalPrice,
          items
        });
        console.log("✅ Email sent successfully");
      } catch (emailErr) {
        console.error("❌ Email send failed:", emailErr.message);
      }
    } else {
      console.warn("⚠️ User email not found.");
    }

    return res.status(201).json({ message: 'Order placed', order });
  } catch (err) {
    console.error("❌ Order placement error:", err);
    return res.status(500).json({ message: 'Order failed', error: err.message });
  }
});

// ✅ Get orders for a user
router.get('/orders/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({ message: 'Missing userId' });
    }

    const orders = await Order.find({ user: userId }).sort({ createdAt: -1 });
    return res.json(orders);
  } catch (err) {
    console.error("❌ Fetch orders error:", err);
    return res.status(500).json({ message: 'Cannot fetch orders', error: err.message });
  }
});

module.exports = router;
