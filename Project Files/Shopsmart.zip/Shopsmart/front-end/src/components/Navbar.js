// src/components/Navbar.js
import React from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react'; // icon
import './Navbar.css';

function Navbar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div className="nav-container">
        {/* Left side: Brand + links */}
        <div className="nav-left">
          <Link to="/" className="brand">
            {/* Logo image or icon */}
            {/* If you have logo.png in public/, replace ShoppingCart with: 
                <img src="/logo.png" alt="ShopSmart" className="brand-icon" /> */}
            <ShoppingCart className="brand-icon" />
            <span className="brand-text">
              <span className="brand-part1">Shop</span>
              <span className="brand-part2">Smart</span>
            </span>
          </Link>
          <ul className="nav-links">
            <li>
              <NavLink 
                to="/" 
                className={({ isActive }) => isActive ? 'active-link' : undefined}
              >
                Home
              </NavLink>
            </li>
            <li>
              <NavLink 
                to="/products" 
                className={({ isActive }) => isActive ? 'active-link' : undefined}
              >
                Products
              </NavLink>
            </li>
            <li>
              <NavLink 
                to="/cart" 
                className={({ isActive }) => isActive ? 'active-link' : undefined}
              >
                Cart
              </NavLink>
            </li>
            <li>
              <NavLink 
                to="/orders" 
                className={({ isActive }) => isActive ? 'active-link' : undefined}
              >
                Orders
              </NavLink>
            </li>
          </ul>
        </div>

        {/* Right side: Login/Signup or greeting + Logout */}
        <div className="nav-right">
          {user ? (
            <>
              <span className="user-greet">Hello, {user.name}</span>
              <button className="logout-btn" onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <NavLink 
                to="/login" 
                className={({ isActive }) => isActive ? 'active-link' : undefined}
              >
                Login
              </NavLink>
              <NavLink 
                to="/signup" 
                className={({ isActive }) => isActive ? 'active-link' : undefined}
              >
                Signup
              </NavLink>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
