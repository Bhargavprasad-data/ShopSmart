import React from 'react';
import './Home.css'; // Optional: for extra styling

function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '40px' }}>
      <h1 className="page-title">Welcome to ShopSmart Grocery Store</h1>
      <p>Get fresh groceries delivered at your doorstep</p>

      {/* Image at the bottom */}
      <div style={{ marginTop: '50px' }}>
        <img 
          src="/fruits.jpg" 
          alt="Fruits and Vegetables" 
          style={{ width: '100%', maxWidth: '900px', borderRadius: '10px' }} 
        />
      </div>
    </div>
  );
}

export default Home;
