import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { CartContext } from '../context/CartContext';

function Products() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [quantities, setQuantities] = useState({});
  const [added, setAdded] = useState({}); // ✅ Track added items

  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    axios.get('http://localhost:5000/api/products')
      .then(res => setProducts(res.data))
      .catch(err => console.error(err));
  }, []);

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleQuantityChange = (id, value) => {
    setQuantities({ ...quantities, [id]: parseInt(value) || 1 });
  };

  const handleAddToCart = (product) => {
    const quantity = quantities[product._id] || 1;
    addToCart(product, quantity);
    setAdded(prev => ({ ...prev, [product._id]: true })); // ✅ Mark as added
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2 className="page-title">Products</h2>

      {/* search box... */}
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <input 
          type="text"
          placeholder="Search for groceries..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{
            padding: '10px',
            width: '300px',
            borderRadius: '5px',
            border: '1px solid #ccc',
            backgroundColor:'#fff',
            color:'000'
          }}
        />
      </div>

      {filteredProducts.map(product => (
        <div key={product._id} style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            border: '1px solid #ccc',
            padding: '15px',
            margin: '15px 0',
            borderRadius: '10px',
            backgroundColor: added[product._id] ? '#dcdcdc' : '#fff',// ✅ Dim background if added
            // color: added[product._id] ? '#f1f1f1' : '#000'

          }}
        >
          <div>
            <h4 style={{color: added[product._id] ? '#fff' : '#000'}}>{product.name}</h4>
            <p style={{color: added[product._id] ? '#ccc' : '#333'}}>Price: ₹{product.price}</p>

            <input
              type="number"
              min="1"
              value={quantities[product._id] || 1}
              onChange={(e) => handleQuantityChange(product._id, e.target.value)}
              style={{
                width: '60px',
                padding: '6px',
                marginBottom: '10px',
                borderRadius: '4px',
                border: '1px solid #444',
                backgroundColor:'#fff',
                color:'#000',
              }}
            /><br />

            <button 
              onClick={() => handleAddToCart(product)} 
              style={{
                padding: '8px 12px',
                marginTop: '10px',
                 backgroundColor: added[product._id] ? '#1e7e34' : '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                textDecoration: added[product._id] ? 'line-through' : 'none' // ✅ Line-through effect
              }}
            >
              Add to Cart
            </button>
          </div>
          <img 
            src={product.image} 
            alt={product.name} 
            style={{ width: '120px', height: '120px', objectFit: 'cover', borderRadius: '8px' }}
          />
        </div>
      ))}
    </div>
  );
}

export default Products;
