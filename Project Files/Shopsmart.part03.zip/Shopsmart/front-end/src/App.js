import React from 'react';
import './App.css';
import './style.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Products from './components/Products';
import Cart from './components/Cart';
import Login from './components/Login';
import Signup from './components/Signup';
import ProtectedRoute from './components/ProtectedRoute';
import OrderHistory from './components/OrderHistory';
import ForgotPassword from './components/ForgotPassword';

function App() {
    return (
        <Router>
            <Navbar />
            <Routes>
                {/* Public Routes */}
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />

                {/* Protected Routes */}
                <Route path="/" element={
                    <ProtectedRoute><Home /></ProtectedRoute>
                } />
                <Route path="/forgot-password" element={<ForgotPassword />} />

                <Route path="/products" element={
                    <ProtectedRoute><Products /></ProtectedRoute>
                } />
                <Route path="/cart" element={
                    <ProtectedRoute><Cart /></ProtectedRoute>
                } />
                <Route
                    path="/orders"
                    element={
                        <ProtectedRoute><OrderHistory /></ProtectedRoute>
                    }
                />
            </Routes>
        </Router>
    );
}

export default App;
