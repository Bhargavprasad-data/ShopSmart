// script.js

// Simple alert when form is submitted
export function showLoginAlert() {
  alert('Login form submitted!');
}

export function showSignupAlert() {
  alert('Signup form submitted!');
}
